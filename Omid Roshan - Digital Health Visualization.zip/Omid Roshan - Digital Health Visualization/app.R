# Load required libraries
pacman::p_load(
  shiny,
  shinythemes,
  rio,          # for importing data
  here,         # for file paths
  janitor,      # for data cleaning
  ggplot2,      # for plotting and making graphs
  plotly,       # adding pie chart and other plot functions 
  tidyverse,    # for data management
  dplyr,        # for modifying column names
  rsconnect
  )

#read csv or XLSX files and store them each in separate variable
p_activity_2004_raw <- import(here('2004_Canada_PhysicalActivity_Age12to17.csv'))
p_activity_2015_raw <- import(here('2015_Canada_PhysicalActivity_Age12to17.csv'))
bmi_2004_to_2015_raw <- import(here('2004_2015_Canada_BMI_Age12to17.csv'))
p_activity_2022_minutes_raw <- readxl::read_xlsx(here("2018_2022_physicalactivity_12to17.xlsx"))
screentime_raw <- here("2018_2021_screentime_12to17_.xlsx")

#datasets sourced from: https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1310079801 - PA 2015

                        #https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1310047101 - PA 2004

                        #https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1310079501 - BMI 2004 and 2015

                        #https://www150.statcan.gc.ca/n1/pub/82-003-x/2023010/article/00001-eng.htm - PA (2018 to 2022) and screen time (2018 and 2021)

#one excel file has sheets so here we store the names and data in another container
sheet_1 <- "School_day"
sheet_2 <- "Non_School_day"
screentime_s1_raw <- readxl::read_xlsx(screentime_raw, sheet = sheet_1)
screentime_s2_raw <- readxl::read_xlsx(screentime_raw, sheet = sheet_2)

#clean the linelists
p_activity_2004 <- p_activity_2004_raw %>%   # create clean linelist
  rename (population_count = VALUE) %>% #change column name from value to population_count
  clean_names() %>% # standardize syntax of column names
  filter(characteristics == "Number of persons") # keep only rows with number of persons

p_activity_2015 <- p_activity_2015_raw %>%
  rename (population_count = VALUE) %>% 
  clean_names()  
 
bmi_2004_to_2015 <- bmi_2004_to_2015_raw %>%
  rename (population_count = VALUE) %>% 
  clean_names()

p_activity_2022_minutes <- p_activity_2022_minutes_raw %>%
  clean_names()

screentime_s1 <- screentime_s1_raw %>%
  clean_names()

screentime_s2 <- screentime_s2_raw %>%
  clean_names()

# view(p_activity_2004)
# view(p_activity_2015)
# view(bmi_2004_to_2015)
# view(screentime_s1)

# Define UI
ui <- fluidPage(
  theme = shinytheme("yeti"),
  titlePanel("Promoting Active Lifestyles: Insights into Canadian Youth Physical Activity Trends"), 
  
  mainPanel(
    navbarPage(
      "",

      tabPanel("Homepage",
                      fluidRow(tags$head(tags$style(HTML("pre { white-space: pre-wrap; word-break: keep-all; }"))), #ui for text container
                               textOutput("home_text")
                      )),
      tabPanel("Physical Activity Comparison 2004/2015",
        fluidRow(column(8,  # Use the full width of the column
        plotOutput("groupedbar_1", height = "500px", width = "800px")),  # Adjust height and width as needed
        column(12,  
               fluidRow(tags$head(tags$style(HTML("pre { white-space: pre-wrap; word-break: keep-all; }"))),
                        textOutput("PA_0415_text")
               ))
        )
      )
      ,tabPanel("BMI comparison 2004/2015",
        fluidRow(column(7, 
        plotOutput("groupedbar_2", height = "500px", width = "800px")),
        column(12,  
               fluidRow(tags$head(tags$style(HTML("pre { white-space: pre-wrap; word-break: keep-all; }"))),
                        textOutput("BMI_0415_text")
               ))
        )
      )
      ,tabPanel("Physical Activity Comparison 2018-2022",
                fluidRow(
                  column(7,  
                         plotOutput("lineplot", height = "500px", width = "1000px"))
                ),
                fluidRow(
                  column(7, 
                         plotOutput("placeholder_plot", height = "50px", width = "500px")) #empty plot to create some space between the 2 graphs
                ),
                fluidRow(
                  column(7, 
                         plotOutput("barplot_meeting", height = "500px", width = "800px")),
                  column(12,  
                         fluidRow(tags$head(tags$style(HTML("pre { white-space: pre-wrap; word-break: keep-all; }"))),
                                  textOutput("PA_1822_text")
                         ))
                )
      )
      ,tabPanel("Screentime Comparison 2018-2021",
                fluidRow(
                  column(7,  # Use the full width of the column
                         plotOutput("lineplot_s1", height = "500px", width = "800px"))
                ),
                fluidRow(
                  column(7, 
                         plotOutput("placeholder_plot2", height = "50px", width = "500px")) #empty plot to create some space between the 2 graphs
                ),
                fluidRow(
                  column(7, 
                         plotOutput("lineplot_s2", height = "500px", width = "800px")),  
                  column(12,  
                         fluidRow(tags$head(tags$style(HTML("pre { white-space: pre-wrap; word-break: keep-all; }"))),
                                  textOutput("ST_1821_text")
                         ))
                )
      )
    )
  )
)

# Define server
server <- function(input, output) {
  
  # home page text
  output$home_text <- renderPrint({
    cat(paste0("Addressing insufficient physical activity (PA) among Canadian youth, aged 12 to 17, is crucial for present and future positive health development. Despite the known benefits, many children are not meeting recommended activity levels, leading to concerns about long-term health issues. Visual aids such as simple graphs can help stakeholders understand the problem and its impact, facilitating informed decision-making and intervention strategies. Parents, educators, health officials, policymakers, and communities all play essential roles in promoting PA among children, emphasizing the need for collaborative efforts. Trends from 2004 to 2015 highlight a concerning decrease in PA levels and stagnant changes in childhood obesity, with efforts required to reverse this trend and address associated the health risks. The COVID-19 pandemic further exacerbated the issue, leading to fluctuations in physical activity levels, emphasizing the need for resilience and adaptable strategies. Additionally, increased screen time poses challenges to children's overall health, necessitating a balanced approach to technology use and physical activity promotion. The tabs on the navigation bar will provide the statistical evidence to these trends, with all data sourced directly from Statistics Canada.")
    )})
  
  #--------------------------server code for Physical Activity Comparison 2004/2015 data -------------------------------------------------
  
  # Define the order of levels for childrens_physical_activity
  activity_levels <- c(
    "Total survey population",
    "less than 7 hours per week",
    "7 to 13 hours per week",
    "14 to 20 hours per week",
    "21 or more hours per week",
    "hours per week, not stated"
  )
  
  # Assuming you have a variable "population_count" for Y-axis
  output$groupedbar_1 <- renderPlot({
    
    # Combine data from p_activity_2004 and p_activity_2015
    combined_data <- bind_rows(
      mutate(p_activity_2004, dataset = "2004"),
      mutate(p_activity_2015, dataset = "2015")
    )
    
    # Remove "Children's physical activity, " from childrens_physical_activity
    combined_data$childrens_physical_activity <- 
      gsub("Children's physical activity, ", "", combined_data$childrens_physical_activity)
    
    # Replace "Total population for the variable children's physical activity" with "Total survey population"
    combined_data$childrens_physical_activity[combined_data$childrens_physical_activity == "Total population for the variable children's physical activity"] <- "Total survey population"
    
    # Set the order of levels for childrens_physical_activity
    combined_data$childrens_physical_activity <- factor(
      combined_data$childrens_physical_activity,
      levels = activity_levels
    )
    
    # Plot grouped bar chart
    p <- ggplot(combined_data, aes(x = childrens_physical_activity, y = population_count, fill = dataset)) +
      geom_bar(stat = "identity", position = position_dodge()) +
      geom_text(aes(label = population_count), position = position_dodge(width = 0.9), vjust = -0.5) +  # Add population_count labels above bars
      labs(title = "Physical Activity Comparison (Ages 12-17)",
           x = "Amount of PA per week",
           y = "Population Count",
           fill = "YEAR") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12))  # Modify axis text size
    
    # Change the size of the whole bar graph
    ggsave("barplot.png", p, width = 12, height = 7, units = "in", dpi = 300)
    
    # Print the plot
    print(p)
  })
  
  #text under p_activity_2004 and p_activity_2015 combined graph
  output$PA_0415_text <- renderPrint({
    cat(paste0("Physical activity (PA) trends among Canadian youth aged 12-17 for the years 2004 and 2015 show us some important changes in activity levels. The main concern here being the significant increase in youth engaging in less than 7 hours of PA per week, almost doubling from 2004 to 2015. There was also a decrease in those doing 7 to 13 and 14 to 20 hours of activity, where the public health recommendations lie, suggesting a move towards a more sedentary lifestyle. Those with 21 or more hours of PA a week saw a slight increase. These findings highlight the need to promote more PA, and combat potential health and well-being issues among Canadian youth.")
    )})
  
  #--------------------------server code for BMI comparison 2004/2015 data -------------------------------------------------
  
  # Define the order of levels for measured_child_body_mass_index
  bmi_levels <- c(
    "Total survey population",
    "neither overweight nor obese",
    "overweight",
    "obese"
  )
  
  output$groupedbar_2 <- renderPlot({
    
    # Combine data from bmi_2004_to_2015
    bmi_combined_data <- bind_rows(
      mutate(bmi_2004_to_2015, dataset = "2004"),
      mutate(bmi_2004_to_2015, dataset = "2015")
      , .id = "source") %>%
      group_by(measured_child_body_mass_index, ref_date, source, .drop = TRUE) %>%
      summarise(population_count = sum(population_count), .groups = 'drop')
    
    # Remove "Measured child body mass index, " from measured_child_body_mass_index
    bmi_combined_data$measured_child_body_mass_index <- 
      gsub("Measured child body mass index, ", "", bmi_combined_data$measured_child_body_mass_index)
    
    # Replace "Total population for the variable measured child body mass index" with "Total survey population"
    bmi_combined_data$measured_child_body_mass_index[bmi_combined_data$measured_child_body_mass_index == "Total population for the variable measured child body mass index"] <- "Total survey population"
    
    # Set the order of levels for measured_child_body_mass_index
    bmi_combined_data$measured_child_body_mass_index <- factor(
      bmi_combined_data$measured_child_body_mass_index,
      levels = bmi_levels
    )
    
    # Plot grouped bar chart with side-by-side bars
    p <- ggplot(bmi_combined_data, aes(x = measured_child_body_mass_index, y = population_count, fill = as.factor(ref_date))) +
      geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
      geom_text(aes(label = population_count), position = position_dodge(width = 0.9), vjust = -0.5) +  # Add population_count labels above bars
      labs(title = "Body Mass Index Comparison (Ages 12-17)",
           x = "BMI Classification",
           y = "Population Count",
           fill = "YEAR") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12),  # Modify axis text size
            legend.position="top")  # Move the legend to the top
    
    # Change the size of the whole bar graph
    ggsave("barplot_bmi.png", p, width = 12, height = 8, units = "in", dpi = 300)
    
    # Print the plot
    print(p)
  })
  
  output$BMI_0415_text <- renderPrint({
    cat(paste0("When looking at Body Mass Index (BMI) trends for 2004 and 2015, the shifts are more subtle than physical activity. There's a small drop in youth classified as within a healthy weight range and a minor decrease in those considered overweight. However, there's a slight increase in youth classified as obese, indicating some challenges in addressing childhood obesity. The main concern here being that any, if at all, health interventions implemented during this 11-year time period have not made much of a real impact on fostering a healthy lifestyle and combating obesity among youth.")
    )})
  
  #--------------------------server code for Physical Activity Comparison 2018-2022 (daily minutes) data -------------------------------------------------
  
  #server code for line graph using p_activity_2022_minutes
  output$lineplot <- renderPlot({
    
    # Filter out "Meeting the physical activity recommendation"
    filtered_data <- filter(p_activity_2022_minutes, category != "Meeting the physical activity recommendation")
    
    # Define the order of columns for x-axis
    x_columns <- c("jan_2018", "dec_2018", "jan_2020", "mar_2020", "sept_2020", "dec_2020", "jan_2021", "feb_2022")
    
    # Melt the data to long format
    melted_data <- pivot_longer(filtered_data, cols = x_columns, names_to = "month", values_to = "value")
    
    # Convert the "month" column to factor with specified order
    melted_data$month <- factor(melted_data$month, levels = x_columns)
    
    # Plot line chart
    p <- ggplot(melted_data, aes(x = month, y = value, group = category, color = category)) +
      geom_line() +
      geom_point() +  # Add points for better visibility +
      geom_text(aes(label = round(value, 2)), vjust = -0.5, show.legend = FALSE) +  # Add text labels above each point
      labs(title = "Physical Activity Comparison (Ages 12-17)",
           x = "Period (Month_Year)",
           y = "Minutes Daily",
           color = "") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12),  # Modify axis text size
            legend.position = "top",
            legend.text = element_text(size = 12))
    
    # Change the size of the whole line graph
    ggsave("lineplot.png", p, width = 12, height = 7, units = "in", dpi = 300)
    
    
    print(p)
  })
  
  # Define the render function for the gap between the two visualizations
  output$placeholder_plot <- renderPlot({
    par(mar = c(0.5, 0.5, 0.5, 0.5))  # Adjust margins as needed
    plot(0, type = "n", axes = FALSE, xlab = "", ylab = "")
  })
  
  #--------------------------server code for Physical Activity Comparison 2018-2022 (meeting the recommendation) data -------------------------------------------------
    
  # Define the render function for the bar plot for "Meeting the physical activity recommendation"
  output$barplot_meeting <- renderPlot({
    # Filter the data for "Meeting the physical activity recommendation"
    meeting_data <- filter(p_activity_2022_minutes, category == "Meeting the physical activity recommendation")
    
    # Define the order of columns for x-axis
    x_columns <- c("jan_2018", "dec_2018", "jan_2020", "mar_2020", "sept_2020", "dec_2020", "jan_2021", "feb_2022")
    
    # Melt the data to long format
    melted_data <- pivot_longer(meeting_data, cols = x_columns, names_to = "month", values_to = "value")
    
    # Convert the "month" column to factor with specified order
    melted_data$month <- factor(melted_data$month, levels = x_columns)
    
    # Plot bar chart
    p <- ggplot(melted_data, aes(x = month, y = value)) +
      geom_bar(stat = "identity", fill = "lightblue") +
      geom_text(aes(label = round(value, 2)), vjust = -0.5) +  # Add value labels above bars
      labs(title = "Meeting Physical Activity Recommendation (Ages 12-17)",
           x = "Period (Month_Year)",
           y = "Percentage (%)") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12))  # Modify axis text size
    
    # Change the size of the whole bar graph
    ggsave("barplot_meeting.png", p, width = 12, height = 7, units = "in", dpi = 300)
    
    print(p)
  })
  
  #text under p_activity_2022
  output$PA_1822_text <- renderPrint({
    cat(paste0("From January 2018 to January 2021, there were significant changes in the daily minutes that Canadian youth (ages 12-17) spent on physical activity (PA). Here we also see the influence on PA by the COVID-19 pandemic and related lockdowns. Total daily physical activity varied noticeably, dropping significantly during certain periods of heightened restrictions. The two areas that influenced this drop most were recreational and school-based PA, suggesting most sources of PA the youth engage in are in organized settings, outside of home. Household or occupation-related PA showed minor changes, likely reflecting varying demands on youth' time and energy within these environments. While the proportion of youth meeting recommended physical activity guidelines was already concerning, hovering around 50%, it dropped drastically during peak lockdown periods, highlighting the impact of restrictive measures on main sources of youth activity levels. While activity minutes began to rise in February 2022, these findings emphasize the complex relationship between external circumstances, environmental factors, and individual behaviors in shaping youth physical activity during times of crisis.")
    )})
  
  #--------------------------server code for Screentime Comparison 2018-2021 (school days) data -------------------------------------------------  
  
  #server code for line graph using screentime_s1 (for school days)
  output$lineplot_s1 <- renderPlot({
    
  
    melted_data <- pivot_longer(screentime_s1, cols = c(x2018, x2021), names_to = "Year", values_to = "value")
    
    # Plot line chart
    p <- ggplot(melted_data, aes(x = Year, y = value, group = hours_per_day, color = hours_per_day)) +
      geom_text(aes(label = value), position = position_dodge(width = 0.6), vjust = -0.5) +
      geom_line() +
      geom_point() +  # Add points for better visibility
      labs(title = "Screen Time Comparison (Ages 12-17) - School Days",
           x = "Year",
           y = "Percentage (%)",
           color = "") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12),  # Modify axis text size
            legend.position = "top",
            legend.text = element_text(size = 14))
    
    
    print(p)
  })
  
  # Define the render function for the gap between the two visualizations
  output$placeholder_plot2 <- renderPlot({
    par(mar = c(0.5, 0.5, 0.5, 0.5))  # Adjust margins as needed
    plot(0, type = "n", axes = FALSE, xlab = "", ylab = "")
  })
  
  #--------------------------server code for Screentime Comparison 2018-2021 (non-school days) data -------------------------------------------------  
  
  #server code for line graph using screentime_s2 (for non school days)
  output$lineplot_s2 <- renderPlot({
    
    
    melted_data <- pivot_longer(screentime_s2, cols = c(x2018, x2021), names_to = "Year", values_to = "value")
    
    # Plot line chart
    p <- ggplot(melted_data, aes(x = Year, y = value, group = hours_per_day, color = hours_per_day)) +
      geom_text(aes(label = value), position = position_dodge(width = 0.6), vjust = -0.5) +
      geom_line() +
      geom_point() +  # Add points for better visibility
      labs(title = "Screen Time Comparison (Ages 12-17) - Non-School Days",
           x = "Year",
           y = "Percentage (%)",
           color = "") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels for better visibility
            plot.title = element_text(size = 15, face = "bold"),  # Modify title size
            axis.title = element_text(size = 13, face = "bold"),  # Modify axis title size
            axis.text = element_text(size = 12),  # Modify axis text size
            legend.position = "top",
            legend.text = element_text(size = 14))
    
    
    print(p)
  })
  
  #text under screentime_s1 and screentime_s2
  output$ST_1821_text <- renderPrint({
    cat(paste0("Analyzing screentime habits among Canadian youth aged 12-17 from 2018 to 2021, both during school days and non-school days, reveals significant shifts, influenced by the COVID-19 pandemic and lockdowns. On school days, there was a notable increase in the proportion of youth spending four or more hours daily on screens, while those with less than two hours of screentime saw a notable decline. Similarly, on non-school days, there was an uptick in prolonged screentime and a decrease in shorter durations. These findings underscore the lack of youth aged 12 to 17 meeting the recommendation of about 2 hours of screen time a day, worsened by lockdown restrictions and the increasing digitization of society.")
    )})
  
}
  
# Run the application
shinyApp(ui, server)
